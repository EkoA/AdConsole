 				<div class="col-md-4 col-sm-5">
                  <ul class="nav-news-feed">
                                    
                    <li><a href="">Place Ads</a></li>	
                    <li><i class="icon ion-ios-paper"></i><div><a href="{{route('ads.create')}}">Place Ads</a></div></li>
                    <li><i class="icon ion-ios-eye"></i><div><a href="{{route('ads.index')}}">View Ads</a></div></li>
                    <li><i class="icon ion-cash"></i><div><a href="{{route('users.wallet')}}">Wallet</a></div></li>
                    <li><i class="icon ion-log-out"></i><div><a href="{{ url('/logout') }}">Logout</a></div></li>
                  </ul>

                </div> 