Dear {{$name}},

Your Payment of {{$amount}} for an advert on Olync was successful via https://olync.net

Your Payment reference is {{$tranx_ref}}

Contact info@olync.net for enquiries.
